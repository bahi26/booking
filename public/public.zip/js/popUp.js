function popUp() {
 //    var popup = document.getElementById("myPopup");
    document.getElementById("myPopup").classList.add("show");
  //  popup.classList.toggle("show");
}
function popdown() {
 document.getElementById("myPopup").classList.remove("show");
    
}