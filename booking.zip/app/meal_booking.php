<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class meal_booking extends Model
{
    //
}
