<?php

namespace App\Http\Controllers;

use App\exercise;
use App\employee;

use Illuminate\Http\Request;

class ExerciseController extends Controller
{
    //
    public function view()
    {
        $exercises = exercise::all();
        $data = array('exercises' => $exercises);
        return view('Exercise.view', $data);
    }
    public function create(Request $request)
    {
        $employees = employee::where('type',"=",'freelancer')->get();


        if($request->isMethod('post'))
        {
            $exercise=new exercise();
            $exercise->name=$request->input("name");
            $exercise->duration=$request->input("duration");
            $exercise->calories=$request->input("calories");
            $exercise->employee_id=$request->input("employee_id");

            $exercise->save();


            return redirect("/viewExercise");
        }
        $data = array('employees' => $employees);

        return view('Exercise.create',$data);
    }
}
