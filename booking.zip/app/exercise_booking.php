<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class exercise_booking extends Model
{
    //
}
