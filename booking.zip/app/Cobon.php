<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cobon extends Model
{
    //
}
