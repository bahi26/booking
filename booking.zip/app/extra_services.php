<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class extra_services extends Model
{
    //
}
