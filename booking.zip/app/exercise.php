<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class exercise extends Model
{
    //
}
